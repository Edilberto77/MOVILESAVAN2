package com.example.proyectdisco

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Obtener referencias a los botones
        val buttonEnter = findViewById<Button>(R.id.buttonEnter)
        val buttonEventos = findViewById<Button>(R.id.buttonEvents)
        val buttonInvitados = findViewById<Button>(R.id.buttonInvitados)
        val buttonReservarmesa = findViewById<Button>(R.id.buttonmesa)
        val buttonPromotions = findViewById<Button>(R.id.buttonPromotions)
        val buttonContact = findViewById<Button>(R.id.buttonContact)

        // Establecer un listener de clic para el botón de entrada
        buttonEnter.setOnClickListener {
            // Abrir la nueva actividad al hacer clic en el botón de entrada
            val intent = Intent(this, Entrar::class.java)
            startActivity(intent)
        }

        // Establecer un listener de clic para el botón de eventos
        buttonEventos.setOnClickListener {
            // Aquí defines el comportamiento deseado cuando se hace clic en el botón de eventos
            // Por ejemplo, abrir una nueva actividad relacionada con eventos
            val intent = Intent(this, Eventos::class.java)
            startActivity(intent)
        }

        // Establecer un listener de clic para el botón de invitados
        buttonInvitados.setOnClickListener {
            // Aquí defines el comportamiento deseado cuando se hace clic en el botón de invitados
            // Por ejemplo, abrir una nueva actividad relacionada con la lista de invitados
            val intent = Intent(this, invitados::class.java)
            startActivity(intent)
        }



        // Puedes agregar listeners de clic para otros botones y definir el comportamiento deseado aquí
        // Por ejemplo, puedes abrir otras actividades o ejecutar cierta lógica cuando se haga clic en esos botones
    }
}