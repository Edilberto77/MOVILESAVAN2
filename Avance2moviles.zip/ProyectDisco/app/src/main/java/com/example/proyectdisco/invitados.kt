package com.example.proyectdisco

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class invitados : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invitados)
// Obtener referencia al botón "Volver al menú"
        val buttonBackToMenu = findViewById<Button>(R.id.buttonBackToMenu)

        // Establecer un listener de clic para el botón "Volver al menú"
        buttonBackToMenu.setOnClickListener {
            // Acción que deseas realizar al hacer clic en el botón "Volver al menú"
            // Por ejemplo, abrir la actividad MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}