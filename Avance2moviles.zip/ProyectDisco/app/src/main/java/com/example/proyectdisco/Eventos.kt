package com.example.proyectdisco

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent

class Eventos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_eventos)

        // Obtener referencia al botón "Volver al menú" en la actividad de eventos
        val buttonBackToMenu = findViewById<Button>(R.id.buttonBackToMenu)

        // Establecer un listener de clic para el botón "Volver al menú"
        buttonBackToMenu.setOnClickListener {
            // Acción que deseas realizar al hacer clic en el botón "Volver al menú"
            // Por ejemplo, abrir la actividad MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
